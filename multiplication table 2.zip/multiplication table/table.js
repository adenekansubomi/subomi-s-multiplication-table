
// Prompt user to enter two numbers
let num1 = prompt("Enter first number:");
let num2 = prompt("Enter second number:");

// Validate if inputs are numbers
if (isNaN(num1) || isNaN(num2)) {
  alert("Please enter valid numbers.");
} else {
  num1 = parseInt(num1);
  num2 = parseInt(num2);

  // Create table
  let table = document.createElement("table");
  table.border = "1";

  // Create table header
  let headerRow = document.createElement("tr");
  let headerCell1 = document.createElement("th");
  headerCell1.textContent = "Number";
  let headerCell2 = document.createElement("th");
  headerCell2.textContent = "Result";
  headerRow.appendChild(headerCell1);
  headerRow.appendChild(headerCell2);
  table.appendChild(headerRow);
  
  // Generate table rows
  for (let i = 1; i <= 50; i++) {
    let row = document.createElement("tr");
    let cell1 = document.createElement("td");
    cell1.textContent = `${num1} x ${num2} x ${i}`;
    let cell2 = document.createElement("td");
    cell2.textContent = num1 * i * num2;
    row.appendChild(cell1);
    row.appendChild(cell2);
    table.appendChild(row);
  }

  // Append table to body
  document.body.appendChild(table);
}

